
import UIKit

func isValidEmailAddress(_ email: String) -> Bool {
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
    return emailPredicate.evaluate(with: email)
}

func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
    // Регулярное выражение для проверки номера телефона
    let phoneNumberRegEx = "^\\d+$"
    let phoneNumberPredicate = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegEx)
    return phoneNumberPredicate.evaluate(with: phoneNumber)
}

class ViewController: UIViewController, UIImagePickerControllerDelegate,UIPickerViewDelegate, UIPickerViewDataSource, UINavigationControllerDelegate {
    let scrollView = UIScrollView()
    let contentView = UIView()
    let labelError = UILabel()
    let graphPicker = UITextField()
    let fullNameTextField = UITextField()
    let contactsTextField = UITextField()
    let dolTextField = UITextField()
    let emailTextField = UITextField()
    let addressTextField = UITextField()
    let aboutTextField = UITextField()
    let selectPhotoButton = UIButton(type: .system)
    let submitButton = UIButton(type: .system)
    let addJobButton = UIButton(type: .system)
    
    var jobFieldsStackView = UIStackView()
    var jobFieldCount = 0
    var selectedImage: UIImage?
    let work = ["Полный день 5/2", "Полный день 2/2","Неполный день 5/2","Неполный день 2/2","Подработка"]
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
        view.backgroundColor = .white
        
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
        ])
        
        labelError.numberOfLines = 0
        
        jobFieldsStackView.axis = .vertical
        jobFieldsStackView.spacing = 10
        
        let stackView = UIStackView(arrangedSubviews: [fullNameTextField,dolTextField,graphPicker, contactsTextField, emailTextField, addressTextField, aboutTextField, selectPhotoButton, addJobButton, jobFieldsStackView, submitButton, labelError])
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            stackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20)
        ])
        
        fullNameTextField.placeholder = "ФИО"
        dolTextField.placeholder = "Желаемая должность"
        contactsTextField.placeholder = "Номер телефона"
        emailTextField.placeholder = "Электронная почта"
        addressTextField.placeholder = "Адрес проживания"
        aboutTextField.placeholder = "О себе"
        graphPicker.placeholder = "График работы"
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        graphPicker.inputView = pickerView
        selectPhotoButton.setTitle("Выбрать фото", for: .normal)
        selectPhotoButton.addTarget(self, action: #selector(selectPhoto), for: .touchUpInside)
        
        addJobButton.setTitle("Добавить место работы", for: .normal)
        addJobButton.addTarget(self, action: #selector(addJobFields), for: .touchUpInside)
        
        submitButton.setTitle("Получить резюме", for: .normal)
        submitButton.addTarget(self, action: #selector(handleSubmit), for: .touchUpInside)
            }
            
            @objc func selectPhoto() {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .photoLibrary
                present(imagePicker, animated: true, completion: nil)
            }
            
            func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
                if let image = info[.originalImage] as? UIImage {
                    selectedImage = image
                }
                dismiss(animated: true, completion: nil)
            }
            
            @objc func addJobFields() {
                jobFieldCount += 1
                let jobStackView = UIStackView()
                jobStackView.axis = .vertical
                jobStackView.spacing = 10
                jobStackView.translatesAutoresizingMaskIntoConstraints = false
                
                let jobTitleLabel = UILabel()
                jobTitleLabel.text = "Место работы под номером \(jobFieldCount)"
                
                let jobDurationTextField = UITextField()
                jobDurationTextField.placeholder = "Срок работы"
                
                let jobPositionTextField = UITextField()
                jobPositionTextField.placeholder = "Должность"
                
                let jobDescriptionTextField = UITextField()
                jobDescriptionTextField.placeholder = "Что делали на работе"
                
                let removeJobButton = UIButton(type: .system)
                removeJobButton.setTitle("Удалить место работы", for: .normal)
                removeJobButton.addTarget(self, action: #selector(removeJobFields(_:)), for: .touchUpInside)
                
                jobStackView.addArrangedSubview(jobTitleLabel)
                jobStackView.addArrangedSubview(jobDurationTextField)
                jobStackView.addArrangedSubview(jobPositionTextField)
                jobStackView.addArrangedSubview(jobDescriptionTextField)
                jobStackView.addArrangedSubview(removeJobButton)
                
                jobFieldsStackView.addArrangedSubview(jobStackView)
            }
            
            @objc func removeJobFields(_ sender: UIButton) {
                if let jobStackView = sender.superview as? UIStackView {
                    jobStackView.removeFromSuperview()
                    jobFieldCount -= 1
                    // Update the job titles
                    updateJobTitles()
                }
            }
            
            func updateJobTitles() {
                for (index, subview) in jobFieldsStackView.arrangedSubviews.enumerated() {
                    if let jobStackView = subview as? UIStackView, let jobTitleLabel = jobStackView.arrangedSubviews.first as? UILabel {
                        jobTitleLabel.text = "Место работы под номером \(index + 1)"
                    }
                }
            }
            
            @objc func handleSubmit() {
                var errors = ""
                if !isValidEmailAddress(emailTextField.text!) {
                    errors = "Введите корректную почту \n"
                }
                if !isValidPhoneNumber(contactsTextField.text!) {
                    errors += "Введите корректный номер\n"
                }
                
                guard let fullName = fullNameTextField.text, !fullName.isEmpty,
                      let contacts = contactsTextField.text, !contacts.isEmpty,
                      let dol = dolTextField.text, !dol.isEmpty,
                      let graphic = graphPicker.text, !graphic.isEmpty,
                      let email = emailTextField.text, !email.isEmpty,
                      let address = addressTextField.text, !address.isEmpty,
                      let about = aboutTextField.text, !about.isEmpty else {
                    labelError.text = "Заполните все поля \n" + errors
                    labelError.textColor = .red
                    labelError.textAlignment = .center
                    return
                }
                
                var experience = ""
                for subview in jobFieldsStackView.arrangedSubviews {
                    if let jobStackView = subview as? UIStackView {
                        let jobFields = jobStackView.arrangedSubviews.compactMap { $0 as? UITextField }
                        if jobFields.count == 3, let jobDuration = jobFields[0].text, let jobPosition = jobFields[1].text, let jobDescription = jobFields[2].text, !jobDuration.isEmpty, !jobPosition.isEmpty, !jobDescription.isEmpty {
                            experience += "\nМесто работы: \(jobDuration), \nДолжность: \(jobPosition), \nОписание: \(jobDescription)"
                        }
                    }
                }
                        
                let userData = UserData(fullName: fullName, doln: dol,graph:graphic, number: jobFieldCount ,contacts: contacts + " " + email + " " + address, experience: experience, about: about, photo: selectedImage)
                        let previewVC = PDFPreviewViewController()
                        previewVC.userData = userData
                        navigationController?.pushViewController(previewVC, animated: true)
                    }
    func numberOfComponents(in pickerView: UIPickerView)->Int{
        return 1
    }
    func pickerView(_ pickerView:UIPickerView, numberOfRowsInComponent component: Int)-> Int{
        return work.count
    }
    func pickerView(_ pickerView:UIPickerView, titleForRow row: Int,forComponent component: Int)-> String?{
        return work[row]
    }
    func pickerView(_ pickerView:UIPickerView, didSelectRow row: Int,inComponent component: Int){
        graphPicker.text = work[row]
        graphPicker.resignFirstResponder()
    }
    
    
                }

struct UserData {
    let fullName: String
    let doln: String
    let graph: String
    let number: Int
    let contacts: String
    let experience: String
    let about: String
    let photo: UIImage?
}
