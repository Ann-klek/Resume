import PDFKit

func drawText(text: String, at point: CGPoint, fontSize: CGFloat, color: UIColor, context: CGContext) {
    let textRect = CGRect(x: point.x, y: point.y, width: 555, height: 1000)
    let paragraphStyle = NSMutableParagraphStyle()
    paragraphStyle.lineBreakMode = .byWordWrapping
    paragraphStyle.alignment = .left
    
    let attributes: [NSAttributedString.Key: Any] = [
        .font: UIFont.systemFont(ofSize: fontSize),
        .paragraphStyle: paragraphStyle,
        .foregroundColor: color
    ]
    
    let attributedText = NSAttributedString(string: text, attributes: attributes)
    attributedText.draw(in: textRect)
}

class PDFGenerator {
    static func generatePDF(with data: UserData, style: PDFStyle) -> Data {
        let pdfMetaData = [
            kCGPDFContextCreator: "My App",
            kCGPDFContextAuthor: "Author",
            kCGPDFContextTitle: "User Survey"
        ]
        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = pdfMetaData as [String: Any]
        
        let pageWidth = 8.5 * 72.0
        let pageHeight = 11 * 72.0
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)
        
        let data = renderer.pdfData { (context) in
            context.beginPage()
            
            switch style {
            case .style1:
                drawStyle1(data: data, context: context, pageRect: pageRect)
            case .style2:
                drawStyle2(data: data, context: context, pageRect: pageRect)
            case .style3:
                drawStyle3(data: data, context: context, pageRect: pageRect)
            }
        }
        
        return data
    }
    
    static func drawStyle1(data: UserData, context: UIGraphicsPDFRendererContext, pageRect: CGRect) {
        
        let margin: CGFloat = 20.0
        var yOffset: CGFloat = margin
                
                // Draw Gradient Background
        let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
        colors: [UIColor.systemBlue.cgColor, UIColor.systemGreen.cgColor] as CFArray,
        locations: [0.0, 1.0])!
        let startPoint = CGPoint(x: 0, y: 0)
        let endPoint = CGPoint(x: 8.5 * 72.0, y: 11 * 72.0)
        context.cgContext.drawLinearGradient(gradient, start: startPoint, end: endPoint, options: [])
                
                // Draw Vertical Stripe
        let stripeRect = CGRect(x: 0, y: 0, width: 250, height: 11 * 72.0)
        context.cgContext.setFillColor(UIColor.black.withAlphaComponent(0.7).cgColor)
        context.cgContext.fill(stripeRect)
        let title = "Резюме"
        drawText(text: title, at: CGPoint(x: 320, y: 20), fontSize: 50, color: .white, context: context.cgContext)
    
        if let image = data.photo {
                   let imageRect = CGRect(x: margin, y: margin, width: 200, height: 200)
                   image.draw(in: imageRect)
                   yOffset = 100
               }
        let spisok = data.fullName.split(separator: " ")
        let fio = spisok.joined(separator: "\n")
        let name = "ФИО: \(fio)"
                drawText(text: name, at: CGPoint(x: margin, y: 250+margin), fontSize: 24, color: .white, context: context.cgContext)
        let dol = "Желаемая должность:\n \(data.doln)"
                drawText(text: dol, at: CGPoint(x: margin, y: 340+margin), fontSize: 24, color: .white, context: context.cgContext)
        let spiso = data.contacts.split(separator: " ")
        let cont = spiso.joined(separator: "\n")
        let contacts = "Контакты:\n \(cont)"
                drawText(text: contacts, at: CGPoint(x: margin , y: margin + 410), fontSize: 24, color: .white, context: context.cgContext)

        let experience = "Опыт работы:\(data.experience)"
        drawText(text: experience, at: CGPoint(x: margin+250, y: yOffset + 140), fontSize: 24, color: .white, context: context.cgContext)
        
        let about = "О себе: \(data.about)"
        drawText(text: about, at: CGPoint(x: margin+250, y: yOffset + 80), fontSize: 24, color: .white, context: context.cgContext)
        let grap = "Желаемый график работы:\n \(data.graph)"
        drawText(text: grap, at: CGPoint(x: margin+250, y: yOffset + 20), fontSize: 24, color: .white, context: context.cgContext)

        
    }
    
    static func drawStyle2(data: UserData, context: UIGraphicsPDFRendererContext, pageRect: CGRect) {
        
        let margin: CGFloat = 20.0
        var yOffset: CGFloat = margin
                
        // Background Color
        let backgroundColor = UIColor.systemTeal
        context.cgContext.setFillColor(backgroundColor.cgColor)
        context.cgContext.fill(pageRect)
                
        // Draw Header Strip
        let headerHeight: CGFloat = 150.0
        let headerRect = CGRect(x: 0, y: 0, width: 8.5 * 72.0, height: headerHeight)
        context.cgContext.setFillColor(UIColor.darkGray.cgColor)
        context.cgContext.fill(headerRect)
        
        // Add Photo
        if let image = data.photo {
            let imageRect = CGRect(x: margin, y: yOffset+20, width: 200, height: 200)
            image.draw(in: imageRect)
            yOffset += 200
        }
        
        let title = "Резюме"
        drawText(text: title, at: CGPoint(x: 270, y: 50), fontSize: 50, color: .white, context: context.cgContext)
        yOffset += 40
        
        let name = "ФИО: \(data.fullName)"
        drawText(text: name, at: CGPoint(x: margin, y: yOffset), fontSize: 30, color: .white, context: context.cgContext)
        yOffset += 40
        let contacts = "Контакты: \(data.contacts)"
            drawText(text: contacts, at: CGPoint(x: margin, y: yOffset), fontSize: 24, color: .white, context: context.cgContext)
            yOffset += 40
        // Add Experience
        let dol = "Желаемая должность: \(data.doln)"
        drawText(text: dol, at: CGPoint(x: margin, y: yOffset), fontSize: 24, color: .white, context: context.cgContext)
        yOffset += 40
        let grap = "Желаемый график работы: \(data.graph)"
        drawText(text: grap, at: CGPoint(x: margin, y: yOffset), fontSize: 24, color: .white, context: context.cgContext)
        yOffset += 50
        let about = "О себе: \(data.about)"
        drawText(text: about, at: CGPoint(x: margin, y: yOffset), fontSize: 30, color: .white, context: context.cgContext)
        yOffset += 40
        let experience = "Опыт работы:\(data.experience)"
        drawText(text: experience, at: CGPoint(x: margin, y: yOffset), fontSize: 30, color: .white, context: context.cgContext)
        
        //about.draw(at: CGPoint(x: 20, y: 150), withAttributes: textAttributes)
        
        
        // Custom drawing for style 2
    }
    
    static func drawStyle3(data: UserData, context: UIGraphicsPDFRendererContext, pageRect: CGRect) {
        
        let margin: CGFloat = 20.0
        var yOffset: CGFloat = margin
                
                // Background Color
        let backgroundColor = UIColor.lightGray
        context.cgContext.setFillColor(backgroundColor.cgColor)
        context.cgContext.fill(pageRect)
                
                // Draw Header with Accents
        let headerHeight: CGFloat = 120.0
        let headerRect = CGRect(x: 0, y: 0, width: 8.5 * 72.0, height: headerHeight)
        context.cgContext.setFillColor(UIColor.systemIndigo.cgColor)
        context.cgContext.fill(headerRect)
                
                // Draw Accents
        let accentColor = UIColor.white
        let accentRect = CGRect(x: 0, y: headerHeight - 20, width: 8.5 * 72.0, height: 40)
        context.cgContext.setFillColor(accentColor.cgColor)
        context.cgContext.fill(accentRect)
                
        let title = "Резюме"
        drawText(text: title, at: CGPoint(x: 230, y: headerHeight + margin), fontSize: 50, color: .black, context: context.cgContext)
        yOffset += 100
        
        if let image = data.photo {
            let imageRect = CGRect(x: margin, y: headerHeight / 2 - 40, width: 150, height: 150)
            image.draw(in: imageRect)
               }
        let name = "ФИО: \(data.fullName)"
                drawText(text: name, at: CGPoint(x: margin + 180, y: margin), fontSize: 20, color: .white, context: context.cgContext)
        let dol = "Желаемая должность: \(data.doln)"
                drawText(text: dol, at: CGPoint(x: margin + 180, y: margin + 40), fontSize: 20, color: .white, context: context.cgContext)
        let contacts = "Контакты: \(data.contacts)"
                drawText(text: contacts, at: CGPoint(x: margin + 180, y: margin + 80), fontSize: 18, color: .black, context: context.cgContext)
        yOffset = headerHeight + 4*margin
        let experience = "Опыт работы:\(data.experience)"
        drawText(text: experience, at: CGPoint(x: margin, y: yOffset), fontSize: 30, color: .black, context: context.cgContext)
        yOffset += 2*(margin+50)*CGFloat(data.number)
        let about = "О себе: \(data.about)"
        drawText(text: about, at: CGPoint(x: margin, y: yOffset), fontSize: 30, color: .black, context: context.cgContext)
        // Custom drawing for style 3
        let grap = "Желаемый график работы: \(data.graph)"
        drawText(text: grap, at: CGPoint(x: margin, y: yOffset + 30), fontSize: 30, color: .black, context: context.cgContext)
    }
}
