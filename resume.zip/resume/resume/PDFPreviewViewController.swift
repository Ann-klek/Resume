import UIKit
import PDFKit

class PDFPreviewViewController: UIViewController {
    
    var userData: UserData!
    var selectedStyle: PDFStyle = .style1
    var pdfView: PDFView!
    
    let styleSegmentedControl: UISegmentedControl = {
        let control = UISegmentedControl(items: ["Стиль 1", "Стиль 2", "Стиль 3"])
        control.selectedSegmentIndex = 0
        return control
    }()
    
    let sendButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Отправить резюме", for: .normal)
        button.addTarget(self, action: #selector(sendPDF), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        pdfView = PDFView()
        pdfView.translatesAutoresizingMaskIntoConstraints = false
        pdfView.autoScales = true
        view.addSubview(pdfView)
        
        styleSegmentedControl.addTarget(self, action: #selector(styleChanged), for: .valueChanged)
        
        let buttonStackView = UIStackView(arrangedSubviews: [styleSegmentedControl, sendButton])
        buttonStackView.axis = .vertical
        buttonStackView.spacing = 10
        buttonStackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(buttonStackView)
        
        NSLayoutConstraint.activate([
            pdfView.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            pdfView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            pdfView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            pdfView.bottomAnchor.constraint(equalTo: buttonStackView.topAnchor, constant: -20),
            
            styleSegmentedControl.heightAnchor.constraint(equalToConstant: 44),
            sendButton.heightAnchor.constraint(equalToConstant: 44),
            
            buttonStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            buttonStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            buttonStackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
        
        updatePDFPreview()
    }
    
    @objc func styleChanged() {
        selectedStyle = PDFStyle(rawValue: styleSegmentedControl.selectedSegmentIndex) ?? .style1
        updatePDFPreview()
    }
    
    @objc func sendPDF() {
        let pdfData = PDFGenerator.generatePDF(with: userData, style: selectedStyle)
        let activityViewController = UIActivityViewController(activityItems: [pdfData], applicationActivities: nil)
        present(activityViewController, animated: true, completion: nil)
    }
    
    func updatePDFPreview() {
        let pdfData = PDFGenerator.generatePDF(with: userData, style: selectedStyle)
        let pdfDocument = PDFDocument(data: pdfData)
        pdfView.document = pdfDocument
    }
}

enum PDFStyle: Int {
    case style1 = 0
    case style2
    case style3
}
